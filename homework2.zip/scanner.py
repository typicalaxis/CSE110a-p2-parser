import re

class ScannerException(Exception):
    
    # this time, the scanner exception takes a line number
    def __init__(self, lineno):
        message = "Scanner error on line: " + str(lineno)
        super().__init__(message)

class Scanner:
    def __init__(self, tokens):
        self.tokens = tokens
        self.lineno = 1

    def input_string(self, input_string):
        self.istring = input_string

    # Get the scanner line number, needed for the parser exception
    def get_lineno(self):
        return self.lineno

    # Implement me with one of your scanner implementations for part
    # 2. I suggest the SOS implementation. If you are not comfortable
    # using one of your own scanner implementations, you can use the
    # EMScanner implementation
    def token(self):    #my sosscanner implementation
        while True:
            if len(self.istring) == 0:
                return None
            matches = []
            for t in tokens:
                matches.append((t[0],re.match(t[1], self.istring),t[2]))
           
            matches = [m for m in matches if m[1] is not None]
            if len(matches) == 0:
                print("here")
                print(self.istring)
                raise ScannerException(self.lineno);
            longest = matches[0]
            
            lexeme = longest[2]((longest[0],longest[1][0]),self)
            if(len(matches) > 1):
                for m in matches:
                    Newlexeme = m[2]((m[0],m[1][0]),self)
                    if(len(lexeme[1]) <  len(Newlexeme[1])):
                        lexeme = Newlexeme 

            chop = len(lexeme[1])
            self.istring = self.istring[chop:]

            #print(lexeme[1])

            if lexeme[0] != "IGNORE":
                return lexeme
            #else:
             #   longest[3](self,lexeme)


def idy(t,scanner):
    if(t[1] == "\n"):
        scanner.lineno +=1
    if(t[1] == "if"):
        return("IF","if")
    elif(t[1] == "else"):
        return("ELSE","else")
    elif(t[1] == "for"):
        return("FOR","for")
    elif(t[1] == "int"):
        return("INT","int")
    elif(t[1] == "float"):
        return("FLOAT","float")
    else:
        return t

# Finish providing tokens (including token actions) for the C-simple
# language
tokens = [
    ("ID",     "[a-zA-Z][a-zA-Z0-9]*", idy),
    ("NUM",    "([0-9]*\.)?[0-9]+", idy),
    #("NUM",    "[0-9]+", idy),
    ("IGNORE", " |\n",   idy),
    ("SUB", "-",   idy),
    ("ADD", "\+",   idy),
    ("MULT", "\*",   idy),
    ("DIV", "/",   idy),
    ("SEMI", ";",   idy),
    ("LPAR", "\(",   idy),
    ("RPAR", "\)",   idy),
    ("LBRA", "{",   idy),
    ("RBRA", "}",   idy),
    ("ASSI", "\=",   idy),
    ("EQIV", "\=\=",   idy),
    ("LESS", "<",   idy),
    ]
