
# Symbol Table exception, requires a line number and ID
class SymbolTableException(Exception):
    
    def __init__(self, lineno, ID):
        message = "Symbol table error on line: " + str(lineno) + "\nUndeclared ID: " + str(ID)
        super().__init__(message)    

#Implement all members of this class for Part 3
#stack of dictionaries
#stack is scope,dictioaries is symbols
#push scope on each block
class SymbolTable:
    def __init__(self):
        self.stack = [{}]

    def insert(self,ID, info):
        
        i = len(self.stack)-1
        self.stack[i][ID] = info
    def lookup(self,ID):
        
        i = len(self.stack)-1
        while i >= 0:
            
            if(self.stack[i].get(ID) != None):
                return(ID)
            i = i-1
        return (None)
    def push_scope(self):
        self.stack.append({})

    def pop_scope(self):
        self.stack.pop()

class ParserException(Exception):
    
    # Pass a line number, current lexeme, and what tokens are expected
    def __init__(self, lineno, lexeme, tokens):
        message = "Parser error on line: " + str(lineno) + "\nExpected one of: " + str(tokens) + "\nGot: " + str(lexeme)
        super().__init__(message)

class Parser:
    def __init__(self, scanner, use_symbol_table):
        self.scanner = scanner
        self.ust = use_symbol_table
        if(self.ust):
            self.st = SymbolTable()
    # Implement one function in this class for every non-terminal in
    # your grammar using the recursive descent recipe from the book
    # and the lectures for part 2

    # Implement me:
    # s is the string to parse

    # dont return anything, just exception checking
    def parse(self, s): 
        self.scanner.input_string(s)
        self.to_match = self.scanner.token()
        self.parse_statelist()

    def parse_statelist(self):
        if(self.to_match in [None]):
            return
        if(self.to_match[0] in ["FLOAT", "INT","ID","IF","FOR","LBRA"]):
            self.parse_state()
        
        if(self.to_match in [None]):
            return
        elif(self.to_match[0] in ["RBRA"]):
            return
        elif(self.to_match[0] in [ "FLOAT", "INT","ID","IF","FOR","LBRA"]):
            self.parse_statelist()
            return
        
        raise ParserException(self.scanner.get_lineno(),self.to_match[0],["FLOAT", "INT","ID","IF","FOR","LBRA","RBRA"])
    def parse_state(self):
        
        if(self.to_match[0] in ["FLOAT", "INT"]):
            self.parse_dec()
            return
        elif(self.to_match[0] in ["ID"]):
            self.parse_assi()
            return
        elif(self.to_match[0] in ["IF"]):
            self.parse_ifelse()
            return
        elif(self.to_match[0] in ["FOR"]):
            self.parse_for()
            return
        elif(self.to_match[0] in ["LBRA"]):
            self.parse_block()
            return
        raise ParserException(self.scanner.get_lineno(),self.to_match[0],["FLOAT", "INT","ID","IF","FOR","LBRA"])

    def parse_assi(self):
        if(self.to_match[0] in ["ID"]):
            if(self.ust):
                if(self.st.lookup(self.to_match[1]) == None):
                    raise SymbolTableException(self.scanner.get_lineno(),self.to_match[1])
            self.to_match = self.scanner.token()
            if(self.to_match[0] in ["ASSI"]):
                self.to_match = self.scanner.token()
                self.parse_expr()
                if(self.to_match[0] in ["SEMI"]):
                    self.to_match = self.scanner.token()
                    return
                raise ParserException(self.scanner.get_lineno(),self.to_match[0],["SEMI"])
            raise ParserException(self.scanner.get_lineno(),self.to_match[0],["ASSI"])
        raise ParserException(self.scanner.get_lineno(),self.to_match[0],["ID"])
    def parse_assifor(self):
        if(self.to_match[0] in ["ID"]):
            if(self.ust):
                if(self.st.lookup(self.to_match[1]) == None):
                    raise SymbolTableException(self.scanner.get_lineno(),self.to_match[1])
            self.to_match = self.scanner.token()
            if(self.to_match[0] in ["ASSI"]):
                self.to_match = self.scanner.token()
                self.parse_expr()
                return
            raise ParserException(self.scanner.get_lineno(),self.to_match[0],["ASSI"])
        raise ParserException(self.scanner.get_lineno(),self.to_match[0],["ID"])
    def parse_dec(self):
        self.parse_type()
        if(self.to_match[0] in ["ID"]):
            if(self.ust):
                self.st.insert(self.to_match[1],None)
            self.to_match = self.scanner.token()
            if(self.to_match[0] in ["SEMI"]):
                self.to_match = self.scanner.token()
                return
            raise ParserException(self.scanner.get_lineno(),self.to_match[0],["SEMI"])
        raise ParserException(self.scanner.get_lineno(),self.to_match[0],["ID"])
    def parse_ifelse(self):
        if(self.to_match[0] in ["IF"]):
            self.to_match = self.scanner.token()
            if(self.to_match[0] in ["LPAR"]):
                self.to_match = self.scanner.token()
                self.parse_expr()
                if(self.to_match[0] in ["RPAR"]):
                    self.to_match = self.scanner.token()
                    self.parse_state()
                    if(self.to_match[0] in ["ELSE"]):
                        self.to_match = self.scanner.token()
                        self.parse_state()
                        return
                    raise ParserException(self.scanner.get_lineno(),self.to_match[0],["ELSE"])
                raise ParserException(self.scanner.get_lineno(),self.to_match[0],["RPAR"])
            raise ParserException(self.scanner.get_lineno(),self.to_match[0],["LPAR"])
        raise ParserException(self.scanner.get_lineno(),self.to_match[0],["IF"])
    def parse_for(self):
        if(self.to_match[0] in ["FOR"]):
            self.to_match = self.scanner.token()
            if(self.to_match[0] in ["LPAR"]):
                self.to_match = self.scanner.token()
                self.parse_assi()
                
                self.parse_expr()
                if(self.to_match[0] in ["SEMI"]):
                    self.to_match = self.scanner.token()
                    self.parse_assifor()
                    if(self.to_match[0] in ["RPAR"]):
                        self.to_match = self.scanner.token()
                        self.parse_state()
                        return
                    raise ParserException(self.scanner.get_lineno(),self.to_match[0],["RPAR"])
                raise ParserException(self.scanner.get_lineno(),self.to_match[0],["SEMI"])
            raise ParserException(self.scanner.get_lineno(),self.to_match[0],["LPAR"])
        raise ParserException(self.scanner.get_lineno(),self.to_match[0],["FOR"])

    def parse_block(self):
        if(self.to_match[0] in ["LBRA"]):
            if(self.ust):
                self.st.push_scope()
            self.to_match = self.scanner.token()
            self.parse_statelist()
            if(self.to_match[0] in ["RBRA"]):
                if(self.ust):
                    self.st.pop_scope()
                self.to_match = self.scanner.token()
                return
            raise ParserException(self.scanner.get_lineno(),self.to_match[0],["RBRA"])
        raise ParserException(self.scanner.get_lineno(),self.to_match[0],["LBRA"])

    def parse_type(self):
        if(self.to_match[0] in ["INT", "FLOAT"]):
            self.to_match = self.scanner.token()
            return
        raise ParserException(self.scanner.get_lineno(),self.to_match[0],["INT","FLOAT"])
    def parse_expr(self):
        if(self.to_match[0] in ["LPAR"]):
            self.to_match = self.scanner.token()
            self.parse_expr()
            if(self.to_match[0] in ["RPAR"]):
                self.to_match = self.scanner.token()
                return
            raise ParserException(self.scanner.get_lineno(),self.to_match[0],["RPAR"])
        elif(self.to_match[0] in ["ID"]):
            if(self.ust):
              if(self.st.lookup(self.to_match[1]) == None):
                    raise SymbolTableException(self.scanner.get_lineno(),self.to_match[1])  
            self.to_match = self.scanner.token()
            self.parse_expr2()
            return
        elif(self.to_match[0] in ["NUM"]):
            self.to_match = self.scanner.token()
            self.parse_expr2()
            return
        raise ParserException(self.scanner.get_lineno(),self.to_match[0],["LPAR", "ID","NUM"])
    def parse_expr2(self):
        if(self.to_match[0] in ["ADD", "SUB", "MULT", "DIV", "EQIV", "LESS"]):
            self.parse_op()
            if(self.to_match[0] in ["NUM"]):
                self.to_match = self.scanner.token()
                self.parse_expr2()
                return
            elif(self.to_match[0] in ["ID"]):
                if(self.ust):
                    if(self.st.lookup(self.to_match[1]) == None):
                        raise SymbolTableException(self.scanner.get_lineno(),self.to_match[1])
                self.to_match = self.scanner.token()
                self.parse_expr2()
                return
            elif(self.to_match[0] in ["LPAR"]):
                self.to_match = self.scanner.token()
                self.parse_expr()
                if(self.to_match[0] in ["RPAR"]):
                    self.to_match = self.scanner.token()
                    self.parse_expr2()
                    return
                raise ParserException(self.scanner.get_lineno(),self.to_match[0],["RPAR"])
            raise ParserException(self.scanner.get_lineno(),self.to_match[0],["NUM", "ID","LPAR"])
        elif(self.to_match[0] in ["SEMI", "RPAR"]):
            #self.to_match = self.scanner.token()
            return
        raise ParserException(self.scanner.get_lineno(),self.to_match[0],["ADD", "SUB", "MULT", "DIV", "EQIV", "LESS","SEMI", "RPAR"])
    def parse_op(self):
        if(self.to_match[0] in ["ADD", "SUB", "MULT", "DIV", "EQIV", "LESS"]):
            self.to_match = self.scanner.token()
            return
        raise ParserException(self.scanner.get_lineno(),self.to_match[0],["ADD", "SUB", "MULT", "DIV", "EQIV", "LESS"])